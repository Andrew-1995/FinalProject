import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ResturantComponent } from './components/resturant/resturant.component';
import { ValidateComponent } from './components/validate/validate.component';
import { HttpClientModule } from '@angular/common/http';
import { MealsComponent } from './components/meals/meals.component';
import { MealsOfRestaurantsComponent } from './components/meals-of-restaurants/meals-of-restaurants.component';
import { PersonsComponent } from './components/persons/persons.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    AppComponent,
    ResturantComponent,
    ValidateComponent,
    MealsComponent,
    MealsOfRestaurantsComponent,
    PersonsComponent
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
