import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { Person } from 'src/app/model/person';
import { PersonService} from 'src/app/services/person.service';


@Component({
  selector: 'app-persons',
  templateUrl: './persons.component.html',
  styleUrls: ['./persons.component.css']
})
export class PersonsComponent implements OnInit {
  persons :Observable<Person[ ] >;
  constructor(private route: ActivatedRoute,private person: PersonService) { }

  ngOnInit(): void {
   
    this.getPersons();
    
  }

  getPersons(){
    this.persons = this.person.getPersons(); 
    }



  

}
