import { Component, OnInit } from '@angular/core';
import { RestaurantService } from 'src/app/services/restaurant.service';
import { Restaurant } from 'src/app/model/restaurant';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-resturant',
  templateUrl: './resturant.component.html',
  styleUrls: ['./resturant.component.css']
})
export class ResturantComponent implements OnInit {
  restaurants :Observable<Restaurant[]>;
  constructor(private res: RestaurantService) { }

  ngOnInit(): void {
    this.getRestaurants();
    //console.log(restaurants|JSON);
  }


  getRestaurants(){
  this.restaurants = this.res.getRestaurants(); 
  }
}
