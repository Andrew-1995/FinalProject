import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { MealRequest } from 'src/app/model/meal-request';
import { VmInitiative } from 'src/app/model/vm-initiative';
import { VmMeal } from 'src/app/model/vm-meal';
import { VmMealRequest } from 'src/app/model/vm-meal-request';
import { InitiativeService } from 'src/app/services/initiative.service';
import { MealrequestService } from 'src/app/services/mealrequest.service';
import { MealsService } from 'src/app/services/meals.service';

@Component({
  selector: 'app-meals-of-restaurants',
  templateUrl: './meals-of-restaurants.component.html',
  styleUrls: ['./meals-of-restaurants.component.css']
})
export class MealsOfRestaurantsComponent implements OnInit {
  meals :Observable<VmMeal[ ] >;
  id :number ;
  data: MealRequest;
  initiatives:Observable<VmInitiative[ ]>;
  mealsReq: Observable<MealRequest>;
  constructor(private route: ActivatedRoute,private meal: MealsService,private initiative: InitiativeService,private mealReq: MealrequestService) { }
  mealsRequest : MealRequest;



  ngOnInit(): void {
    this.route.params.subscribe(params=>{this.id=params['id']})
    console.log(this.id);
    this.getMealsOfRestaurants();
    console.log(this.meals);
    this.getInitiative();
    //this.mealsRequest = new initiative() ;
  }

  getMealsOfRestaurants(){
    this.meals = this.meal.getMealsOfRestaurants(this.id); 
    }

   


      getInitiative(){
        this.initiatives = this.initiative.getInitiativeOfPerson(this.id); 
        }



      addRequest(){
        this.data=new MealRequest(3,1,1,1,1);
        //this.data=

        this.mealReq.addMealRequest(this.data).subscribe(r=>{
          console.log(JSON.stringify(r));
        });
        
      }

      setvalue(event)
      {
        this.mealsRequest.InitiativeId = event;
        console.log(event);
      }

}
