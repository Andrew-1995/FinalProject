import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MealsOfRestaurantsComponent } from './components/meals-of-restaurants/meals-of-restaurants.component';

import { PersonsComponent } from './components/persons/persons.component';
import { ResturantComponent } from './components/resturant/resturant.component';


//const routes: Routes = [];


const routes: Routes = [
  {   path: '',component: ResturantComponent},
  {   path: 'mealofrestaurants/:id',component: MealsOfRestaurantsComponent},
  {   path: 'person',component: PersonsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})



export class AppRoutingModule { }
