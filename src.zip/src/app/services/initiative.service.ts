import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import * as config from '../config';
import { Observable, pipe, throwError} from 'rxjs';
//import { Meal } from '../model/meal';
import { Initiative } from '../model/initiative';
import { VmInitiative } from '../model/vm-initiative';
import { catchError } from 'rxjs/operators';




@Injectable({
  providedIn: 'root'
})
export class InitiativeService {

  
  constructor(private http: HttpClient) { }
  
  getHeaders():HttpHeaders{
    const headers = new HttpHeaders()
    .set('Content-Type', 'application/json');
    return headers;
    }



    getInitiativeOfPerson(id: number): Observable<VmInitiative[ ]> { 

    
      return this.http
           .get<VmInitiative[ ]>(config.ApiUrl + 'api/Initiatives/OfPerson/'+ id , {headers: this.getHeaders()})     
   }



   getInitiativ(id: number): Observable<VmInitiative[ ]> { 

    
          return this.http
              .get<VmInitiative[ ]>(config.ApiUrl + 'api/Initiatives/'+ id , {headers: this.getHeaders()})     
      }


      addInitiative(data:Initiative):Observable<Initiative> {
        return this.http.post<Initiative>(config.ApiUrl + 'api/Initiatives',
        JSON.stringify(data), { headers: this.getHeaders() })
        .pipe(
          catchError(this.handleError)
        );
        }
      


        deleteInitiative(id:number){ 

  
          return this.http
               .delete(config.ApiUrl + 'api/Initiatives/'+ id, {headers: this.getHeaders()})
               .pipe(
                catchError(this.handleError)
              );     
        }


        updateInitiative(id:number,data: Initiative): Observable<Initiative> {
          return this.http.put<Initiative>(config.ApiUrl + 'api/Initiatives/'+ id, JSON.stringify(data),  {headers: this.getHeaders()})
          .pipe(
            catchError(this.handleError)
          );
        }
        private handleError(error: HttpErrorResponse) {
          if (error.error instanceof ErrorEvent) {
            // A client-side or network error occurred. Handle it accordingly.
            console.error('An error occurred:', error.error.message);
          } else {
            // The backend returned an unsuccessful response code.
            // The response body may contain clues as to what went wrong.
            console.error(`Backend returned code ${error.status}, ` +
              `body was: ${error.error}`);
          }
          // Return an observable with a user-facing error message.
          return throwError('Something bad happened; please try again later.');
        }

  }
