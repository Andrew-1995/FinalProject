import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import * as config from '../config';
import { Observable, pipe, throwError} from 'rxjs';
import { Meal } from '../model/meal';
import { VmMeal } from '../model/vm-meal';
import { catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class MealsService {

  constructor(private http: HttpClient) { }
  
  getHeaders():HttpHeaders{
    const headers = new HttpHeaders()
    .set('Content-Type', 'application/json');
    return headers;
    }

  getMeals(): Observable<VmMeal[ ]> { 

    
    return this.http
         .get<VmMeal[ ]>(config.ApiUrl + 'api/Meals/' , {headers: this.getHeaders()})     
 }
 getMealsOfRestaurants(id:number): Observable<VmMeal[ ]> { 

  
  return this.http
       .get<VmMeal[ ]>(config.ApiUrl + 'api/Meals/OfRestaurant/'+ id, {headers: this.getHeaders()})     
}




addMeal(data:Meal):Observable<Meal> {
  return this.http.post<Meal>(config.ApiUrl + 'api/Meals',
  JSON.stringify(data), { headers: this.getHeaders() })
  .pipe(
    catchError(this.handleError)
  );
  }


  
  deleteMeal(id:number){ 

  
    return this.http
         .delete(config.ApiUrl + 'api/Meals/'+ id, {headers: this.getHeaders()})
         .pipe(
          catchError(this.handleError)
        );     
  }


  updateMeal(id:number,data: Meal): Observable<Meal> {
    return this.http.put<Meal>(config.ApiUrl + 'api/Meals/'+ id, JSON.stringify(data),  {headers: this.getHeaders()})
    .pipe(
      catchError(this.handleError)
    );
  }
  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong.
      console.error(`Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // Return an observable with a user-facing error message.
    return throwError('Something bad happened; please try again later.');
  }

}
