import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpResponse } from '@angular/common/http';
import * as config from '../config';
import { Observable, pipe, throwError} from 'rxjs';
import { Person } from '../model/person';
import { catchError } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class PersonService {

  constructor(private http: HttpClient) { }
  
  getHeaders():HttpHeaders{
    const headers = new HttpHeaders()
    .set('Content-Type', 'application/json');
    return headers;
    }



    
  getPersons(): Observable<Person[ ]> { 

    
    return this.http
         .get<Person[ ]>(config.ApiUrl + 'api/People' , {headers: this.getHeaders()})     
 }

 getPersonId(id:number): Observable<Person> { 

  
  return this.http
       .get<Person>(config.ApiUrl + 'api/People/'+ id, {headers: this.getHeaders()})     
}



addPerson(data:Person):Observable<Person> {
  return this.http.post<Person>(config.ApiUrl + 'api/People',
  JSON.stringify(data), { headers: this.getHeaders() })
  .pipe(
    catchError(this.handleError)
  );
  }




    
  deletePerson(id:number){ 

  
    return this.http
         .delete(config.ApiUrl + 'api/People/'+ id, {headers: this.getHeaders()})     
         .pipe(
          catchError(this.handleError)
        );
  }



  updatePerson(id:number,data: Person): Observable<Person> {
    return this.http.put<Person>(config.ApiUrl + 'api/People/'+ id, JSON.stringify(data),  {headers: this.getHeaders()})
    .pipe(
      catchError(this.handleError)
    );
  }
  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong.
      console.error(`Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // Return an observable with a user-facing error message.
    return throwError('Something bad happened; please try again later.');
  }



}
