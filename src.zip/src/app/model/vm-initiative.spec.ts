import { VmInitiative } from './vm-initiative';

describe('VmInitiative', () => {
  it('should create an instance', () => {
    expect(new VmInitiative()).toBeTruthy();
  });
});
