export class Restaurant {


    public Id: string;
    
    public Name: string;
    
    public Address: string;
    
    public Phone: string;
}
