export class AspNetUsers {
    public Id: string;
    
    public Email: string;
    
    public UserName: string;


}



