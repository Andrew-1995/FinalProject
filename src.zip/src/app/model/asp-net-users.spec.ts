import { AspNetUsers } from './asp-net-users';

describe('AspNetUsers', () => {
  it('should create an instance', () => {
    expect(new AspNetUsers()).toBeTruthy();
  });
});
