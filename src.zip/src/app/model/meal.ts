export class Meal {
    public Id: number;
    
    public Name: string;
    
    public RestaurantId: number;
    
    public Description: string;
    
    public Price: number;
    
    public IsActive: boolean;
}

