import { MealRequest } from './meal-request';

describe('MealRequest', () => {
  it('should create an instance', () => {
    expect(new MealRequest()).toBeTruthy();
  });
});
