export class VmMealRequest {

     
    public Id: number;
    
    public PersonId: number;
    
    public PersonName: string;
    
    public InitiativeId: number;
    
    public MealId: number;
    
    public MealName: string;
    
    public Count: number;
    
    public Price: number;
    
    public TotalPrice: number;

    
}


