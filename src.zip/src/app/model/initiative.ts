export class Initiative {


    public Id: string;
    
    public InitiatorId: number;
    
    public RestaurantId: number;
    
    public DayOfInitiative: Date;
    
    public ExpectedCallTime: Date;

}
