export class MealRequest {

    public Id: number;
    
    public PersonId: number;
    
    public InitiativeId: number;
    
    public MealId: number;
    

    public Count: number;
constructor(Id: number,PersonId: number,InitiativeId: number,MealId: number,Count: number){
    this.Id=Id;
    this.PersonId=PersonId;
    this.InitiativeId=InitiativeId;
    this.MealId=MealId;
    this.Count=Count;
};
}
