export class Person {


    public Id: number;
    
    public UserId: string;
    
    public FirstName: string;
    
    public LastName: string;
    
    public Phone: string;
    
    public Mobile: string;
    
    public IsActive: boolean;

    
}
