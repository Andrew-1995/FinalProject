export class VmInitiative {

    
    public Id: string;
    
    public InitiatorId: number;
    
    public InitiatorName: string;
    
    public RestaurantId: number;
    
    public RestaurantName: string;
    
    public DayOfInitiative: Date;
    
    public ExpectedCallTime: Date;
}
