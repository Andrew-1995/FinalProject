import { Initiative } from './initiative';

describe('Initiative', () => {
  it('should create an instance', () => {
    expect(new Initiative()).toBeTruthy();
  });
});
