import { VmMeal } from './vm-meal';

describe('VmMeal', () => {
  it('should create an instance', () => {
    expect(new VmMeal()).toBeTruthy();
  });
});
