import { VmMealRequest } from './vm-meal-request';

describe('VmMealRequest', () => {
  it('should create an instance', () => {
    expect(new VmMealRequest()).toBeTruthy();
  });
});
