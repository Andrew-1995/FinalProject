export class VmMeal {
    public Id: number;
    
    public Name: string;
    
    public RestaurantId: number;
    
    public RestaurantName: string;
    
    public Description: string;
    
    public Price: number;
    
    public IsActive: boolean;
}
