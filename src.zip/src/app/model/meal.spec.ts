import { Meal } from './meal';

describe('Meal', () => {
  it('should create an instance', () => {
    expect(new Meal()).toBeTruthy();
  });
});
