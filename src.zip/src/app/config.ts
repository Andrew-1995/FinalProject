export var ApiUrl: string = 'http://fooddelivery.somee.com/';
